// Esqueleto da classe na qual devem ser implementadas as novas funcionalidades de desenho

public class ImageEx extends Image {

	public ImageEx(int w, int h, int r, int g, int b){

		super(w, h, r, g, b);
	}

	public ImageEx(int w, int h){

		super(w, h);
	}

	public void kochCurve(int px, int py, int qx, int qy, int l){

	}

	public void regionFill(int x, int y, int reference_rgb){

	}
}
